<?php get_header(); ?>

<?php get_template_part('Module/Post/post_1_1_0/post_1_1_0'); ?>

<?php get_footer(); ?>