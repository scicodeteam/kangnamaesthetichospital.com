<script>
    (function(){
    var link = document.createElement('link');
        link.type = 'image/x-icon';
        link.rel = 'shortcut icon';
        link.href = '<?php echo get_template_directory_uri(); ?>/options/code_tracking/images/kn_favicon.ico';
    var t=document.getElementsByTagName('script')[0];t.parentNode.insertBefore(link,t)})();
    var _domain =location.host;
    var url = window.location.href; 
</script>




<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-217267740-1"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-5XMJZGZ3FQ"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-88412900-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-217267740-1');
  gtag('config', 'G-5XMJZGZ3FQ');
  gtag('config', 'UA-88412900-1');
</script>

<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '1216077185086864');
    fbq('track', 'PageView');
</script>

<?php if (is_page(4705) || is_page(7102)):?>
    <script>
    fbq('track', "CompleteRegistration");
    </script>
    <!-- <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=1216077185086864&ev=PageView&noscript=1"
    /></noscript> -->

<?php endif; ?>

<!-- Code tracking Insight KangNam -->
<script src="<?php echo get_template_directory_uri(); ?>/options/code_tracking/js.js?t=1"></script>

<script>
  var ref = document.referrer;
  //set cookies
  function setCookie(cname, cvalue, exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
      var expires = "expires=" + d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  //get cookies    
  function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for (var i = 0; i < ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0) == ' ') {
              c = c.substring(1);
          }
          if (c.indexOf(name) == 0) {
              return c.substring(name.length, c.length);
          }
      }
      return "";
  }

  //Tách chuỗi link
  function locurl(url) {
      var parse_url = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
      var result = parse_url.exec(url);
      var res = result[3].replace(/www./gi, '');
      return res;
  }
  if(ref.length){
      var ref_host = locurl(ref);
      var landing_url =  document.URL;
      var home_url = locurl(landing_url);
      if(ref_host != home_url){
          var first_url = landing_url;
          var refer = ref;
          setCookie('ref', refer, 30);
          setCookie('first_url', first_url, 30);
      }else{
          var refer = getCookie('ref');
          var first_url = getCookie('first_url');
      }
      console.log(refer);
      console.log(first_url);
  }
</script>

<!-- Live chat -->
<!-- <script type="text/javascript">
    function loadJsAsync(t,e){
        var n = document.createElement("script");
        n.type="text/javascript",n.src=t,n.addEventListener("load",function(t){e(null,t)},!1);
        var a = document.getElementsByTagName("head")[0];
        setTimeout(() => {
            a.appendChild(n)
        }, 3000);
    }

    window.addEventListener(
        "DOMContentLoaded",
        function(){loadJsAsync("https://webchat.caresoft.vn:8090/js/CsChat.js?v=4.0",
        function(){var t={domain:"kangnam",domainId:8989};embedCsChat(t)})},!1
    );
</script>
<style>
    @media (max-width:480px){
        iframe#cs_chat_iframe {
            bottom: 80px !important;
        }
    }
</style> -->

<!-- Event GA -->
<!-- <script>
    jQuery(".call").addClass("ClickCall");
    jQuery(".nav-fb,.messenger_1_0_0 a").addClass("ClickChat");
    jQuery(".ClickChat").click(function(){
        gtag("event","ClickChat", {event_category: "EventChat",event_label: "FBChat"});	
    });

    jQuery(".ClickCall").click(function(){
        gtag("event","ClickCall", {event_category: "EventCall",event_label: "MBCall"});
    });
</script> -->

<!-- Messenger Plugin chat Code -->
<div id="fb-root"></div>

<!-- Your Plugin chat code -->
<div id="fb-customer-chat" class="fb-customerchat">
</div>

<script>
  var chatbox = document.getElementById('fb-customer-chat');
  chatbox.setAttribute("page_id", "100191318242952");
  chatbox.setAttribute("attribution", "biz_inbox");
</script>

<!-- Your SDK code -->
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v13.0'
    });
  };

  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
</script>
<style>
    @media (max-width:767px){
        #fb-root iframe {
            bottom: 70px!important;
            right: 0px!important;
        }
    }
</style>