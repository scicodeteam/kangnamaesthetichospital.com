<?php get_header(); ?>
<div style="background:#eee;height:67vh;display:flex;align-items:center">
    <div class="page text-center" style="height: 400px; max-width:800px; margin:0 auto; padding:50px; text-align:center">
        <h1 style="padding: 30px 0;" class="">Nội dung không tìm thấy !</h1>
        <div>Nội dung bạn cầm xem hiện không còn hoặc đã bị xóa. <a href="/" style="color: blue; text-decoration: underline;"><i>Về trang chủ</i></a></div>
    </div>
</div>
	
<?php get_footer(); ?>