<?php
	$path = get_template_directory_uri();
	$path = $path.'/Module/Footer/tool_info_1_2_0';
?>
<style>
.tool_info_1_2_0{position:fixed;background:#fff;right:0;top:130px;z-index:2}
.tool_info_1_2_0__item{width:100%;text-align:center;padding:6px 6px 0;background-color:#fff;margin:0}
.tool_info_1_2_0__item p{margin-bottom:3px}
.tool_info_1_2_0__item a{font-size:13px}
.tool_info_1_2_0__item .icon{padding-top:4px}
.tool_info_1_2_0__item:hover{background:#eee}
.tool_info_1_2_0__call{background:#003664;padding-bottom:10px}
.tool_info_1_2_0__call:hover{background:#004989}
.tool_info_1_2_0__call a{color:#fff;font-weight:600}
.tool_info_1_2_0__uudai{background:#daa236;padding-bottom:10px}
.tool_info_1_2_0__uudai a{color:#fff}
.tool_info_1_2_0__uudai:hover{background:#c78f1e}
.tool_info_1_2_0__vitri{background:#ff8212;padding-bottom:10px}
.tool_info_1_2_0__vitri a{color:#fff}
.tool_info_1_2_0__vitri:hover{background:#ef7b14}
@media (max-width: 767px) {
.tool_info_1_2_0{background:#fff;right:auto;bottom:0;top:auto;width:100%}
.tool_info_1_2_0 img{max-width:24px;height:auto}
.tool_info_1_2_0__box{display:flex;width:428px;margin:0 auto;justify-content:center}
.tool_info_1_2_0__item{height:60px;width:20%;margin:0}
.tool_info_1_2_0__mess{display:none}
}
@media (max-width: 428px) {
.tool_info_1_2_0__box{width:auto}
}
@media (max-width: 280px) {
.tool_info_1_2_0__item a{font-size:11px}
}
</style>   
<div class="tool_info_1_2_0">
    <div class="tool_info_1_2_0__box">
        <div class="tool_info_1_2_0__item tool_info_1_2_0__call">
            <a class="call" href="tel:0016502822885">CALL
                <div class="icon">
                    <img width="30" src="<?php echo $path ?>/images/call.png" alt="Viber">
                </div>
            </a>
        </div>
        <div class="tool_info_1_2_0__item">
            <a class="viber" href="viber://add?number=84969999777">
                <p>Viber</p>
                <img src="<?php echo $path ?>/images/viber.png" alt="Viber">
            </a>
        </div>
        <div class="tool_info_1_2_0__item">
            <a class="whatsapp" target="_blank" href="https://wa.me/+84969999777"> 
                <p>Whatsapp</p>
                <img src="<?php echo $path ?>/images/whatsapp.png" alt="Whatsapp">
            </a>
        </div>
        <div class="tool_info_1_2_0__item tool_info_1_2_0__mess">
            <a class="messenger" target="_blank" href="https://m.me/Thammykangnam"> 
                <p>Messenger</p>
                <img src="<?php echo $path ?>/images/messenger.png" alt="Messenger">
            </a>
        </div>
        <div class="tool_info_1_2_0__item">
            <a class="zalo" target="_blank" href="https://zalo.me/3078465991051061571">
                <p>Zalo</p>
                <img src="<?php echo $path ?>/images/zalo.png" alt="Zalo">
            </a>
        </div>
        <div class="tool_info_1_2_0__item tool_info_1_2_0__uudai">
            <a href="/uu-dai/"> 
                <p>Ưu đãi</p>
                <img width="29" height="21" src="<?php echo $path ?>/images/ud.png" alt="promotion">
            </a>
        </div>
        <div class="tool_info_1_2_0__item tool_info_1_2_0__vitri popup_map_1_0_0__click">
            <a href="#">
                <p>map</p>
                <img width="19" height="23" src="<?php echo $path ?>/images/vt.png" alt="map">
            </a>
        </div>
    </div>
</div>