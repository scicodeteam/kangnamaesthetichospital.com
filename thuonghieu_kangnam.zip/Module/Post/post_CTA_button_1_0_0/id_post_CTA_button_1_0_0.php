 <?php 
                                            /*POST CTA BUTTON 1.0.0*/
                                            'id_post_CTA_button_1_0_0' => array(
                                                'key' => 'id_post_CTA_button_1_0_0',
                                                'name' => 'post_CTA_button_1_0_0',
                                                'label' => 'Post CTA Button 1.0.0',
                                                'display' => 'block',
                                                'sub_fields' => array(
                                                    /*Bắt đầu field*/
                                                    array(
                                                        'key' => 'post_CTA_button_1_0_0_sub1',
                                                        'label' => '',
                                                        'name' => 'post_doctor',
                                                        'type' => 'flexible_content',
                                                        'instructions' => '',
                                                        'required' => 0,
                                                        'conditional_logic' => 0,
                                                        'wrapper' => array(
                                                            'width' => '',
                                                            'class' => '',
                                                            'id' => '',
                                                        ),
                                                        'layouts' => array(
                                                            'layout_homeTitle' => array(
                                                                'key' => 'post_CTA_button_1_0_0_sub1_layout',
                                                                'name' => 'post_CTA_button_1_0_0_sub1_layout',
                                                                'label' => 'CTA Button',
                                                                'display' => 'block',
                                                                'sub_fields' => array(
                                                                    // Bat dau Field
                                                                    array(
                                                                        'key' => 'id_post_CTA_button_1_0_0_tab1_sub1',
                                                                        'label' => 'Mã Shortcode : <b>[post_CTA_button_1_0_0 id=""]</b>',
                                                                        'name' => 'info',
                                                                        'type' => 'textarea',
                                                                        'instructions' => '
                                                                            Dòng 1 : Shortcode id  <br>
                                                                            Dòng 2 : Tiêu đề ( VD: Form tư vấn ) <br>
                                                                            Dòng 2 : Link ảnh nút bấm ( Size 422x76 ) <br>
                                                                            Dòng 3 : Nhập mã form đăng ký ( Form khuyến mãi : bvh_dkkm  /   Form tư vấn : bvh_dktv) <br>
                                                                            Dòng 4 : Nhập sô lượt click ( VD: 45 ) <br>
                                                                        ',
                                                                        'required' => 0,
                                                                        'conditional_logic' => 0,
                                                                        'wrapper' => array(
                                                                            'width' => '',
                                                                            'class' => '',
                                                                            'id' => '',
                                                                        ),
                                                                        'default_value' => '',
                                                                        'placeholder' => '',
                                                                        'maxlength' => '',
                                                                        'rows' => 4,
                                                                        'new_lines' => '',
                                                                    ),                                                                    
                                                                    // End Field Base                       
                                                                ),
                                                                'min' => '',
                                                                'max' => '',
                                                            ),                                              
                                                        ),
                                                        'button_label' => 'Thêm CTA Button',
                                                        'min' => '',
                                                        'max' => '',
                                                    ),
                                                

                                                    /*End field*/
                                                ),
                                                'min' => '',
                                                'max' => '',
                                            ),
                                            /*END POST CTA BUTTON 1.0.0*/  

?>