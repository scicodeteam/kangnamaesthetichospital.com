    <style>
        .pagination_1_0_0 {
            text-align: center
        }
        
        .pagination_1_0_0 .page_nav {
            padding-left: 0
        }
        
        .pagination_1_0_0 .wp-pagenavi {
            display: flex;
            justify-content: center
        }
        
        .pagination_1_0_0 .wp-pagenavi .pages {
            margin: 0 20px 0 0;
            line-height: 30px
        }
        
        .pagination_1_0_0 .wp-pagenavi .current {
            background: #004689;
            color: #fff
        }
        
        .pagination_1_0_0 .wp-pagenavi .current,
        .pagination_1_0_0 .wp-pagenavi a {
            border: 1px solid #004689;
            width: 30px;
            height: 30px;
            display: block;
            line-height: 30px;
            margin: 0 5px
        }
    </style>

	<div class="pagination_1_0_0">
        <?php
            if (function_exists("pagination")) {
                    pagination($custom_query->max_num_pages,2);
                }
            ?>
	</div>


