<?php
	$path = get_template_directory_uri();
	$path = $path.'/Module/Other/tool_info_1_2_0';
?>
<style>
    .btnkn1call,.notiprice,.position{
        cursor: pointer;
    }
    .tool_info_1_2_0{
        height: 69px;
        width:80px;
        position: fixed;
        background: #fff;
        right: 0;
        top: 130px;
        z-index: 1;
    }
    .tool_info_1_2_0__item {
        width: 100%;
        text-align: center;
        padding: 10px 0;
    }
    .tool_info_1_2_0__item:nth-child(1){
        background: #07a738;
    }
    .tool_info_1_2_0__item:nth-child(2){
        background: #246a9a;
    }
    .tool_info_1_2_0__item:nth-child(3){
        background: #1999f1;
    }
    .tool_info_1_2_0__item:nth-child(4){
        background: #daa236;
    }
    .tool_info_1_2_0__item:nth-child(5){
        background: #ff8212;
    }
    
    .tool_info_1_2_0__item a {
        text-decoration: none;
        color: #fff
    }
    
    .tool_info_1_2_0 .icon {
        padding-top: 5px
    }
    
    .tool_info_1_2_0 .call {
        background: #07a738
    }
    
    .tool_info_1_2_0 .zalo {
        background: #246a9a
    }
    
    .tool_info_1_2_0 .messengers {
        background: #1999f1
    }
    
    .tool_info_1_2_0 .baogia {
        background: #daa236
    }
    
    .tool_info_1_2_0 .vitri {
        background: #ff8212
    }
    @media (max-width: 1280px){
        .tool_info_1_2_0{
            width:60px;
        }
        .tool_info_1_2_0__item a{
            font-size:13px;
        }
    }
    
    @media (max-width: 768px) {
        .tool_info_1_2_0{
            display: none;
        }
    }
    
    /*# sourceMappingURL=tool_info_1_2_0.css.map */
</style>   
<div class="tool_info_1_2_0">
    <div class="tool_info_1_2_0__box">
            <div class="tool_info_1_2_0__item">
                <a class="btnkn1call"> Gọi điện
                    <div class="icon">
                        <img width="21" height="21" src="<?php echo $path ?>/images/call.png" alt="Gọi điện">
                    </div>
                </a>
            </div>
            <div class="tool_info_1_2_0__item">
                <a rel="nofollow" target="_blank" href="https://zalo.me/3078465991051061571"> Zalo
                    <div class="icon">
                        <img  width="26" height="25" src="<?php echo $path ?>/images/zalo.png" alt="Zalo">
                    </div>
                </a>
            </div>
            <div class="tool_info_1_2_0__item">
                <a class="notiprice"> Báo giá
                    <div class="icon">
                        <img  width="30" height="19" src="<?php echo $path ?>/images/dola.png" alt="Báo giá">
                    </div>
                </a>
            </div>
            <div class="tool_info_1_2_0__item">
                <a target="_blank" href="/uu-dai/"> Ưu đãi
                    <div class="icon">
                        <img  width="29" height="21" src="<?php echo $path ?>/images/ud.png" alt="Ưu đãi">
                    </div>
            </div></a>
            <div class="tool_info_1_2_0__item">
                <a class="position popup_map_1_0_0__click"> Vị trí
                    <div class="icon">
                        <img  width="19" height="23" src="<?php echo $path ?>/images/vt.png" alt="Vị trí">
                    </div>
                </a>
            </div>
        </div>
</div>


