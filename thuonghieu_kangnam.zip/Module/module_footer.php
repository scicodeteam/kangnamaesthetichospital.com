<?php
    $module_id =  get_option('mfpd_option_name');
    $page_field = get_field('group_page_field',$module_id);
    // Đường dẫn đến theme
    $path = get_template_directory_uri();
    $arrcheck = array();
    $css_inline = '';
    $js_inline = '';

    foreach($page_field as $field_0):
        foreach($field_0 as $field_1):
            foreach($field_1 as $field_2):
            foreach($field_2 as $key => $field):
                $name = $field['acf_fc_layout'];

                if(in_array($name,$arrcheck)){
                    $check = 1;
                }else{
                    array_push($arrcheck,$name);
                    $check = 0;
                }
                include(locate_template('template-footer/content-'.$name.'.php'));
            endforeach;
            endforeach;
        endforeach;
    endforeach;
 
?>
<?php 
    // include(locate_template('Module/media/dist/lib.php'));
    include(locate_template('Module/media/dist/lib-min.php'));
?>


<?php include(locate_template('Module/Footer/tool_info_1_2_0/tool_info_1_2_0.php')); ?>
<?php include(locate_template('Module/Footer/pop_formreg_1_2_0/pop_formreg_1_2_0.php')); ?>
<?php include(locate_template('Module/Popup/popup_1_1_0/popup_1_1_0.php')); ?>
<?php include(locate_template('Module/Popup/popup_map_1_0_0/popup_map_1_0_0.php')); ?>
<?php get_template_part('Module/Popup/popup_call_1_0_0/popup_call_1_0_0'); ?>
<?php include(locate_template('Module/Popup/popup_regist_1_0_1/popup_regist_1_0_1.php')); ?>
<?php include(locate_template('Module/Popup/popup_regist_1_0_2/popup_regist_1_0_2.php')); ?>
<?php include(locate_template('Module/Popup/popup_regist_1_0_8/popup_regist_1_0_8.php')); ?>
<?php include(locate_template('Module/Popup/social_1_0_0/social_1_0_0.php')); ?>
<?php 
    echo $css_inline;
    echo $js_inline;
?>
<?php get_template_part('options/code_tracking/code_tracking'); ?>
