<?php
    $page_field = get_field('group_page_field');
    // Đường dẫn đến theme
    $path = get_template_directory_uri();
    $arrcheck = array();
    $css_inline = '';
    $js_inline = '';
    $view = '';
    foreach($page_field as $field_0){
        foreach($field_0 as $field_1){
            foreach($field_1 as $field_2){
                foreach($field_2 as $field){
                    $name = $field['acf_fc_layout'];
                    if(in_array($name,$arrcheck)){
                        $check = 1;
                    }else{
                        array_push($arrcheck,$name);
                        $check = 0;
                    }
                    include(locate_template('template-parts/content-'.$name.'.php'));
                }
            }
        }
    }
?>
<?php 
    // include(locate_template('Module/media/dist/lib.php'));
    // include(locate_template('Module/media/dist/lib-min.php'));
?>
<script>

// LazyShowScreen('img.lazy','src');
// document.addEventListener("scroll", function () {
//     // Add Onscroll .menu a
//     // Add Lazy Screen LDP
//     myLazy('img.lazy', 'src');
//     myLazy('source.lazy', 'srcset');
//     myLazy('.lazy-bg', 'img-bg');
//     myLazy('.load', 'loaded');
// }); 

<?php
// add Img Lazy Demo
// addImgDefault('img.lazy', 'src');
// addImgDefault('source.lazy', 'srcset');
// function addImgDefault(sec, attr){
//     const section_loads = document.querySelectorAll(sec);
//     let data = 'data:image/gif;base64,R0lGODlhAQABAPAAAMzMzAAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==';

//     for (let i = 0; i < section_loads.length; i++) {
//         // add src default
//         switch(attr){
//             case 'src':
//                 section_loads[i].src = data;
//                 break;
//             case 'srcset':
//                 section_loads[i].srcset = data;
//                 break;
//             default:
//                 console.log(`Sorry, we are out of ${attr}.`);
//         }
//     }    
// }
?>
// function myLazy(sec, attr) {
//     const section_loads = document.querySelectorAll(sec);
//     let winTop = window.innerHeight;
//     for (let i = 0; i < section_loads.length; i++) {
//         let pos_top = section_loads[i].getBoundingClientRect().top;
//         let pos_bottom = section_loads[i].getBoundingClientRect().bottom;       
//         if (pos_top <= winTop && pos_bottom >= 0) {
//             switch(attr){
//                 case 'src':
//                     section_loads[i].src = section_loads[i].dataset.src;
//                     section_loads[i].classList.remove('lazy');
//                     break;
//                 case 'srcset':
//                     section_loads[i].srcset = section_loads[i].dataset.srcset;
//                     section_loads[i].classList.remove('lazy');
//                     break;
//                 case 'img-bg':
//                     // section_loads[i].srcset = section_loads[i].dataset.srcset;
//                     section_loads[i].classList.remove('lazy-bg');
//                     section_loads[i].classList.add('img-bg');
//                     break;
//                 default:
//                     console.log(`Sorry, we are out of ${attr}.`);
//             }
            
//         }
//     }
// }        
// function LazyShowScreen(sec, attr) {
//     const section_loads = document.querySelectorAll(sec);
//     let win_height = screen.height;

//     for (let i = 0; i < section_loads.length; i++) {
//         if(section_loads[i].getBoundingClientRect().top < win_height){
//             switch(attr){
//                 case 'loaded':
//                 section_loads[i].classList.add('loaded');
//                     break;
//                 case 'src':
//                     section_loads[i].src = section_loads[i].dataset.src;
//                     section_loads[i].classList.remove('lazy');
//                     break;
//                 case 'srcset':
//                     section_loads[i].srcset = section_loads[i].dataset.srcset;
//                     section_loads[i].classList.remove('lazy');
//                     break;
//                 case 'img-bg':
//                     section_loads[i].classList.remove('lazy-bg');
//                     section_loads[i].classList.add('img-bg');
//                     break;
//                 default:
//                     console.log(`Sorry, we are out of ${attr}.`);
//             }
//         }
//     }
// }
// </script>
<?php 
    echo $css_inline;
    echo $js_inline;
?>

