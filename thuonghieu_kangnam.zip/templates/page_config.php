<?php 
	/* Template Name: Page Config
	* Template Post Type: page */    
	header("HTTP/1.1 301 Moved Permanently"); 
	header("Location: /"); 
	exit();   
?>
