<?php 
	/* Template Name: Page Home
	* Template Post Type: page
    */       

//set headers to NOT cache a page
header("Cache-Control: no-cache, must-revalidate"); //HTTP 1.1
header("Pragma: no-cache"); //HTTP 1.0
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past

//or, if you DO want a file to cache, use:
header("Cache-Control: max-age=31557600"); //30days (60sec  60min  24hours * 30days)

?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <?php 
    if (current_user_can('administrator') || current_user_can('editor')) {
      wp_admin_bar_render();
      echo '
        <meta name="robots" content="noindex,follow"/>
        <link id="pagestyle" rel="stylesheet" type="text/css" href="/wp-includes/css/admin-bar.min.css?ver=4.9.10" />
        <link id="pagestyle" rel="stylesheet" type="text/css" href="/wp-includes/css/dashicons.min.css?ver=4.9.10" />
      ';
    }
  ?>
    <meta charset="UTF-8">
    <meta name="google-site-verification" content="IB7NazsflCxonm5I-jtz9EjeMeRSs0sb0rkHSYAAhBA" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title() ?></title>
    <?php wp_head(); ?>

    <?php
        include(locate_template('Module/media/css/style_css.php')); 
        include(locate_template('Module/media/dist/lib.php'));
        include(locate_template('Module/media/dist/lib-min.php'));
    ?>
	<link rel="preload" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" as="fetch"  crossorigin="anonymous">
    <style>
        body {
            font-family: Roboto, -apple-system, Helvetica Neue, Arial, sans-serif;
            padding-top: 40px;           
        }     
        /* @media (max-width:1024px)   {
            body {
                padding-top: 65px;
            }
        } */
        .modal-btn {
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php get_template_part('Module/module_header'); ?>
    <?php 
        get_template_part('Module/module');	
        get_template_part('Module/module_footer');
    ?>

    <?php get_template_part('options/code_tracking/code_v2'); ?>
    <script>
    // var sectiol = document.getElementsByTagName("SECTION");
    // for (const secti of sectiol) {
    //     secti.addEventListener("mouseover", mouseOver3);

    //     function mouseOver3() {
    //         boxShow.classList.remove("active");
    //         document.getElementById("icon-menu").innerHTML = "☰";
    //     }
    // }
    </script>
</body>

<?php
echo $css_inline;
echo $js_inline;
?>
<script>
lazyShowScreen('img.lazy', 'src');
document.addEventListener("scroll", function() {
    // Add Lazy Screen LDP
    myLazy('img.lazy', 'src');
    myLazy('source.lazy', 'srcset');
    myLazy('.load', 'loaded', 'load');
});

function myLazy(section, attr, sectionDelete) {
    const section_loads = document.querySelectorAll(section);
    let winTop = window.innerHeight;

    for (let i = 0; i < section_loads.length; i++) {
        let pos_top = section_loads[i].getBoundingClientRect().top;
        let pos_bottom = section_loads[i].getBoundingClientRect().bottom;
        if (pos_top <= winTop && pos_bottom >= 0) {
            if (sectionDelete) {
                section_loads[i].classList.remove(sectionDelete);
                section_loads[i].classList.add(attr);

            } else if (attr == 'srcset') {
                section_loads[i].srcset = section_loads[i].dataset.srcset;
                section_loads[i].classList.remove('lazy');

            } else if (attr == 'src') {
                section_loads[i].src = section_loads[i].dataset.src;
                section_loads[i].classList.remove('lazy');

            } else {
                console.log(`Sorry, we are out of ${attr}.`);
            }
        }
    }
}

function lazyShowScreen(section, attr, sectionDelete) {
    const section_loads = document.querySelectorAll(section);
    let win_height = screen.height;

    for (let i = 0; i < section_loads.length; i++) {
        if (section_loads[i].getBoundingClientRect().top < win_height) {
            if (sectionDelete) {
                section_loads[i].classList.remove(sectionDelete);
                section_loads[i].classList.add(attr);

            } else if (attr == 'srcset') {
                section_loads[i].srcset = section_loads[i].dataset.srcset;
                section_loads[i].classList.remove('lazy');

            } else if (attr == 'src') {
                section_loads[i].src = section_loads[i].dataset.src;
                section_loads[i].classList.remove('lazy');

            } else {
                console.log(`Sorry, we are out of ${attr}.`);
            }
        }
    }
}
</script>