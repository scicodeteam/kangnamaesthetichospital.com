    <?php get_template_part('Module/module_footer'); ?>   
    <script src="<?php echo get_template_directory_uri(); ?>/Module/media/dist/jquery.min.js"></script>
    <?php wp_footer(); ?>
    
</body>

</html>