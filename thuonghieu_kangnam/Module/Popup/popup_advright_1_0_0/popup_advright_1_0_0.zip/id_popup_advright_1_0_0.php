<?php
                                /*POPUP ADV RIGHT 1.0.0*/
                                'id_popup_advright_1_0_0' => array(
                                    'key' => 'id_popup_advright_1_0_0',
                                    'name' => 'popup_advright_1_0_0',
                                    'label' => 'Popup Advright 1.0.0',
                                    'display' => 'block',
                                    'sub_fields' => array(
                                        /*Bắt đầu field*/
                                        array(
                                            /* Tab tiêu đề*/
                                            'key' => 'id_popup_advright_1_0_0_tab1',
                                            'label' => 'Popup Right',
                                            'name' => '',
                                            'type' => 'tab',
                                            'instructions' => '',
                                            'required' => 0,
                                            'conditional_logic' => 0,
                                            'wrapper' => array(
                                                'width' => '',
                                                'class' => '',
                                                'id' => '',
                                            ),
                                            'placement' => 'top',
                                            'endpoint' => 0,
                                        ),
                                        array(
                                            'key' => 'id_popup_advright_1_0_0_tab1_sub',
                                            'label' => 'Cập nhật POPUP theo chỉ dẫn',
                                            'name' => 'data',
                                            'type' => 'textarea',
                                            'instructions' => '
                                                Dòng 1 : Tiêu đề Popup <br>
                                                Dòng 2 : Link Popup <br>
                                                Dòng 3 : Link ảnh hiển thị Desktop (300 x 250px) <br>
                                                Dòng 4 : Link ảnh hiển thị Mobile (320px x 50px)
                                                
                                            ',
                                            'required' => 0,
                                            'conditional_logic' => 0,
                                            'wrapper' => array(
                                                'width' => '',
                                                'class' => '',
                                                'id' => '',
                                            ),
                                            'default_value' => '',
                                            'placeholder' => '',
                                            'maxlength' => '',
                                            'rows' => 6,
                                            'new_lines' => '',
                                        ),
                                        /*End field*/
                                    ),
                                    'min' => '',
                                    'max' => '',
                                ),
                                /*END POPUP ADV RIGHT 1.0.0*/
?>