<?php
                                            /*POPUP NOTI 1.0.0*/
                                            'id_popup_noti_1_0_0' => array(
                                                'key' => 'id_popup_noti_1_0_0',
                                                'name' => 'popup_noti_1_0_0',
                                                'label' => 'Popup noti 1.0.0',
                                                'display' => 'block',
                                                'sub_fields' => array(
                                                    /*Bắt đầu field*/
                                                    array(
                                                        'key' => 'id_popup_noti_1_0_0_sub1',
                                                        'label' => 'Tiêu đề',
                                                        'name' => 'title',
                                                        'type' => 'text',
                                                        'instructions' => '',
                                                        'required' => 0,
                                                        'conditional_logic' => 0,
                                                        'wrapper' => array(
                                                            'width' => '',
                                                            'class' => '',
                                                            'id' => '',
                                                        ),
                                                        'default_value' => '',
                                                        'placeholder' => '',
                                                        'prepend' => '',
                                                        'append' => '',
                                                        'maxlength' => '',
                                                    ),
                                                    array(
                                                        'key' => 'id_popup_noti_1_0_0_sub2',
                                                        'label' => 'Danh sách tin',
                                                        'name' => 'content',
                                                        'type' => 'relationship',
                                                        'instructions' => '',
                                                        'required' => 0,
                                                        'conditional_logic' => 0,
                                                        'wrapper' => array(
                                                            'width' => '',
                                                            'class' => '',
                                                            'id' => '',
                                                        ),
                                                        'post_type' => '',
                                                        'taxonomy' => '',
                                                        'filters' => array(
                                                            0 => 'search',
                                                            1 => 'post_type',
                                                            2 => 'taxonomy',
                                                        ),
                                                        'elements' => array(
                                                            0 => 'featured_image',
                                                        ),
                                                        'min' => '',
                                                        'max' => 4,
                                                        'return_format' => 'id',
                                                    ),
                                                    /*End field*/
                                                ),
                                                'min' => '',
                                                'max' => '',
                                            ),
                                            /*END POPUP NOTI 1.0.0*/  
?>


